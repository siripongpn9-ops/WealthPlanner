-- Wealth Vitality — cloud sync table
-- วิธีใช้: Supabase → SQL Editor → New query → วางทั้งไฟล์นี้ → Run (รันครั้งเดียว)

create table if not exists public.wealth_data (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  data       jsonb       not null default '{}'::jsonb,
  version    integer     not null default 1,
  updated_at timestamptz not null default now(),
  updated_by text
);

-- Row Level Security: แต่ละบัญชีอ่าน/เขียนได้เฉพาะแถวของตัวเองเท่านั้น
alter table public.wealth_data enable row level security;

drop policy if exists "own row - select" on public.wealth_data;
drop policy if exists "own row - insert" on public.wealth_data;
drop policy if exists "own row - update" on public.wealth_data;

create policy "own row - select" on public.wealth_data
  for select to authenticated using (auth.uid() = user_id);

create policy "own row - insert" on public.wealth_data
  for insert to authenticated with check (auth.uid() = user_id);

create policy "own row - update" on public.wealth_data
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ไม่มี policy สำหรับ delete โดยตั้งใจ — ลบข้อมูลจากหน้าเว็บไม่ได้
-- ไม่ให้ anon (คนที่ไม่ได้ login) เข้าถึงตารางนี้เลย
revoke all on public.wealth_data from anon;
grant select, insert, update on public.wealth_data to authenticated;
